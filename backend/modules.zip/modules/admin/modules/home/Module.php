<?php

namespace backend\modules\admin\modules\home;

/**
 * article module definition class
 */
class Module extends \yii\base\Module
{
    /**
     * @inheritdoc
     */
    public $controllerNamespace = 'backend\modules\admin\modules\home\controllers';

    /**
     * @inheritdoc
     */
    public function init()
    {
        parent::init();
    }
    
    
    public function displayJson(){
        
    }
    
}
